﻿namespace WindowsFormsApp1
{
    partial class Gen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lname = new System.Windows.Forms.TextBox();
            this.Fname = new System.Windows.Forms.TextBox();
            this.AGE = new System.Windows.Forms.TextBox();
            this.PatientID = new System.Windows.Forms.TextBox();
            this.GenID = new System.Windows.Forms.TextBox();
            this.Preg = new System.Windows.Forms.TextBox();
            this.Tab = new System.Windows.Forms.TextBox();
            this.Alcohol = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Modify = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.Allergy = new System.Windows.Forms.Button();
            this.Demo = new System.Windows.Forms.Button();
            this.Illness = new System.Windows.Forms.Button();
            this.Family = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Lname
            // 
            this.Lname.BackColor = System.Drawing.Color.Yellow;
            this.Lname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lname.Location = new System.Drawing.Point(204, 105);
            this.Lname.Name = "Lname";
            this.Lname.ReadOnly = true;
            this.Lname.Size = new System.Drawing.Size(100, 26);
            this.Lname.TabIndex = 0;
            // 
            // Fname
            // 
            this.Fname.BackColor = System.Drawing.Color.Yellow;
            this.Fname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fname.Location = new System.Drawing.Point(310, 105);
            this.Fname.Name = "Fname";
            this.Fname.ReadOnly = true;
            this.Fname.Size = new System.Drawing.Size(100, 26);
            this.Fname.TabIndex = 1;
            // 
            // AGE
            // 
            this.AGE.BackColor = System.Drawing.Color.Yellow;
            this.AGE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AGE.Location = new System.Drawing.Point(416, 105);
            this.AGE.Name = "AGE";
            this.AGE.ReadOnly = true;
            this.AGE.Size = new System.Drawing.Size(100, 26);
            this.AGE.TabIndex = 2;
            // 
            // PatientID
            // 
            this.PatientID.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.PatientID.Location = new System.Drawing.Point(55, 105);
            this.PatientID.Name = "PatientID";
            this.PatientID.ReadOnly = true;
            this.PatientID.Size = new System.Drawing.Size(100, 20);
            this.PatientID.TabIndex = 3;
            // 
            // GenID
            // 
            this.GenID.Location = new System.Drawing.Point(484, 224);
            this.GenID.Name = "GenID";
            this.GenID.Size = new System.Drawing.Size(100, 20);
            this.GenID.TabIndex = 4;
            // 
            // Preg
            // 
            this.Preg.Location = new System.Drawing.Point(484, 251);
            this.Preg.Name = "Preg";
            this.Preg.Size = new System.Drawing.Size(100, 20);
            this.Preg.TabIndex = 5;
            // 
            // Tab
            // 
            this.Tab.Location = new System.Drawing.Point(484, 278);
            this.Tab.Name = "Tab";
            this.Tab.Size = new System.Drawing.Size(100, 20);
            this.Tab.TabIndex = 6;
            // 
            // Alcohol
            // 
            this.Alcohol.Location = new System.Drawing.Point(484, 305);
            this.Alcohol.Name = "Alcohol";
            this.Alcohol.Size = new System.Drawing.Size(100, 20);
            this.Alcohol.TabIndex = 7;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(75, 224);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 8;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(87, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "PatientID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(241, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(341, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Last Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(433, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Date of birth";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(90, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(380, 227);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "General Medical ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(412, 254);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Pregnancies";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(433, 281);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Tabacco";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(438, 308);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Alcohol";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(123, 392);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 18;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Visible = false;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(204, 392);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 19;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Visible = false;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(285, 392);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(75, 23);
            this.Modify.TabIndex = 20;
            this.Modify.Text = "Modify";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(366, 393);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 23);
            this.Delete.TabIndex = 21;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(447, 393);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 22;
            this.button5.Text = "Undo";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // Allergy
            // 
            this.Allergy.Location = new System.Drawing.Point(628, 195);
            this.Allergy.Name = "Allergy";
            this.Allergy.Size = new System.Drawing.Size(133, 23);
            this.Allergy.TabIndex = 23;
            this.Allergy.Text = "Open Allergies";
            this.Allergy.UseVisualStyleBackColor = true;
            this.Allergy.Click += new System.EventHandler(this.button1_Click);
            // 
            // Demo
            // 
            this.Demo.Location = new System.Drawing.Point(628, 224);
            this.Demo.Name = "Demo";
            this.Demo.Size = new System.Drawing.Size(133, 23);
            this.Demo.TabIndex = 24;
            this.Demo.Text = "Open Demographics";
            this.Demo.UseVisualStyleBackColor = true;
            this.Demo.Click += new System.EventHandler(this.Demo_Click);
            // 
            // Illness
            // 
            this.Illness.Location = new System.Drawing.Point(628, 253);
            this.Illness.Name = "Illness";
            this.Illness.Size = new System.Drawing.Size(133, 23);
            this.Illness.TabIndex = 25;
            this.Illness.Text = "Open Illness";
            this.Illness.UseVisualStyleBackColor = true;
            this.Illness.Click += new System.EventHandler(this.Illness_Click);
            // 
            // Family
            // 
            this.Family.Location = new System.Drawing.Point(628, 282);
            this.Family.Name = "Family";
            this.Family.Size = new System.Drawing.Size(133, 23);
            this.Family.TabIndex = 26;
            this.Family.Text = "Open Family";
            this.Family.UseVisualStyleBackColor = true;
            this.Family.Click += new System.EventHandler(this.Family_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(341, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(67, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "Medical form";
            // 
            // Gen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Family);
            this.Controls.Add(this.Illness);
            this.Controls.Add(this.Demo);
            this.Controls.Add(this.Allergy);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Alcohol);
            this.Controls.Add(this.Tab);
            this.Controls.Add(this.Preg);
            this.Controls.Add(this.GenID);
            this.Controls.Add(this.PatientID);
            this.Controls.Add(this.AGE);
            this.Controls.Add(this.Fname);
            this.Controls.Add(this.Lname);
            this.Name = "Gen";
            this.Text = "Gen";
            this.Load += new System.EventHandler(this.Gen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Lname;
        private System.Windows.Forms.TextBox Fname;
        private System.Windows.Forms.TextBox AGE;
        private System.Windows.Forms.TextBox PatientID;
        private System.Windows.Forms.TextBox GenID;
        private System.Windows.Forms.TextBox Preg;
        private System.Windows.Forms.TextBox Tab;
        private System.Windows.Forms.TextBox Alcohol;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button Allergy;
        private System.Windows.Forms.Button Demo;
        private System.Windows.Forms.Button Illness;
        private System.Windows.Forms.Button Family;
        private System.Windows.Forms.Label label10;
    }
}